created: 2023-02-27 8h00
Author: Bleeker Maximilien & Wittmann Gregory
Name: ConvertisseurFile
Version: 1.0.0
Description: Convertisseur de fichier

# "PROJET" Creation d'une application de conversion de fichiers
 Ce projet aura pour but de créer une application et de faire site internet permettant aux utilisateurs télécharger l'aaplication et donc de convertir leurs fichiers. Ce projet est réalisé dans le cadre de notre formation de BUT Informatique et encadre notre période de stage de 2 mois.


## "FONCTIONNALITES"

### "FONCTIONNALITE 1" 
L'utilisateur peut choisir un fichier à convertir.

### "FONCTIONNALITE 2"
L'utilisateur peut choisir le format de sortie.

### "FONCTIONNALITE 3"
L'utilisateur peut convertir son fichier.

### "FONCTIONNALITE 4"

L'utilisateur peut télécharger son fichier converti.

## "CONCEPTION"

### "CONCEPTION 0"
L'application sera réalisé en Python.

### "CONCEPTION 1"
Le site internet sera réalisé en HTML, CSS et JavaScript.

### "CONCEPTION 2"
Le site internet sera hébergé sur un serveur ovh (maybe).

### "CONCEPTION 3"
Le site internet sera responsive.

### "CONCEPTION 4"
Le site internet sera sécurisé.